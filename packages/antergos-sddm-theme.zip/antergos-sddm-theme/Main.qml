import QtQuick 2.14
import SddmComponents 2.0
import 'components'


Rectangle {
    id: container
    width: 640
    height: 480

    LayoutMirroring.enabled: Qt.locale().textDirection == Qt.RightToLeft
    LayoutMirroring.childrenInherit: true

    TextConstants { id: textConstants }

    Connections {
        target: sddm

        onLoginSucceeded: {
            errorMessage.color = "#2EA3F2"
            errorMessage.text = textConstants.loginSucceeded
        }

        onLoginFailed: {
            password.text = ""
            errorMessage.color = "red"
            errorMessage.text = textConstants.loginFailed
        }
    }

    Background {
        anchors.fill: parent
        source: config.background
        fillMode: Image.PreserveAspectCrop
        onStatusChanged: {
            if (status == Image.Error && source != config.defaultBackground) {
                source = config.defaultBackground
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        color: "#cc1a1c21"

        Rectangle {
            id: loginCard
            anchors.centerIn: parent
            width: Math.max(340, mainColumn.implicitWidth + 60)
            height: Math.max(360, mainColumn.implicitHeight + 60)
            radius: 12
            color: "#232629"

            Column {
                id: mainColumn
                anchors.centerIn: parent
                spacing: 12
                width: parent.width - 60

                Text {
                    id: brandingText
                    text: "Antergos"
                    color: "#2EA3F2"
                    font.family: "Roboto"
                    font.weight: Font.Light
                    font.pointSize: 32
                    horizontalAlignment: Text.AlignHCenter
                    anchors.horizontalCenter: parent.horizontalCenter
                }

                Text {
                    id: subtitleText
                    text: "NeXT"
                    color: "#eff0f1"
                    font.family: "Roboto"
                    font.weight: Font.Thin
                    font.pointSize: 16
                    horizontalAlignment: Text.AlignHCenter
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.topMargin: -4
                }

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    color: "#9da3b0"
                    verticalAlignment: Text.AlignVCenter
                    height: text.implicitHeight
                    width: parent.width
                    text: textConstants.welcomeText.arg(sddm.hostName)
                    wrapMode: Text.WordWrap
                    font.pixelSize: 14
                    elide: Text.ElideRight
                    horizontalAlignment: Text.AlignHCenter
                }

                Item { height: 8; width: 1 }

                Column {
                    width: parent.width
                    spacing: 4
                    Text {
                        id: lblName
                        width: parent.width
                        text: textConstants.userName
                        font.bold: true
                        font.pixelSize: 13
                        color: '#8a8f9c'
                    }

                    TextBox {
                        id: name
                        width: parent.width; height: 36
                        text: userModel.lastUser
                        font.pixelSize: 14
                        color: '#31363b'
                        textColor: '#eff0f1'
                        focusColor: '#2EA3F2'
                        KeyNavigation.backtab: rebootButton; KeyNavigation.tab: password

                        Keys.onPressed: {
                            if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                                sddm.login(name.text, password.text, session.index)
                                event.accepted = true
                            }
                        }
                    }
                }

                Column {
                    width: parent.width
                    spacing: 4
                    Text {
                        id: lblPassword
                        width: parent.width
                        text: textConstants.password
                        font.bold: true
                        font.pixelSize: 13
                        color: '#8a8f9c'
                    }

                    PasswordBox {
                        id: password
                        width: parent.width; height: 36
                        font.pixelSize: 14
                        color: '#31363b'
                        textColor: '#eff0f1'
                        focusColor: '#2EA3F2'

                        KeyNavigation.backtab: name; KeyNavigation.tab: session

                        Keys.onPressed: {
                            if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                                sddm.login(name.text, password.text, session.index)
                                event.accepted = true
                            }
                        }
                    }
                }

                Row {
                    spacing: 4
                    width: parent.width
                    z: 100

                    Column {
                        z: 100
                        width: parent.width * 0.55
                        spacing: 4
                        anchors.bottom: parent.bottom

                        Text {
                            id: lblSession
                            width: parent.width
                            text: textConstants.session
                            wrapMode: TextEdit.WordWrap
                            font.bold: true
                            font.pixelSize: 13
                            color: '#8a8f9c'
                        }

                        ComboBox {
                            id: session
                            width: parent.width; height: 36
                            font.pixelSize: 14
                            color: '#31363b'
                            textColor: '#eff0f1'
                            menuColor: '#232629'
                            focusColor: '#2EA3F2'
                            hoverColor: '#3f4347'
                            borderColor: '#3f4347'
                            model: sessionModel
                            index: sessionModel.lastIndex

                            KeyNavigation.backtab: password; KeyNavigation.tab: layoutBox
                        }
                    }

                    Column {
                        z: 101
                        width: parent.width * 0.4
                        spacing: 4
                        anchors.bottom: parent.bottom

                        Text {
                            id: lblLayout
                            width: parent.width
                            text: textConstants.layout
                            wrapMode: TextEdit.WordWrap
                            font.bold: true
                            font.pixelSize: 13
                            color: '#8a8f9c'
                        }

                        LayoutBox {
                            id: layoutBox
                            width: parent.width; height: 36
                            color: '#31363b'
                            textColor: '#eff0f1'
                            hoverColor: '#3f4347'
                            menuColor: '#232629'
                            borderColor: '#3f4347'
                            focusColor: '#2EA3F2'

                            KeyNavigation.backtab: session; KeyNavigation.tab: loginButton
                        }
                    }
                }

                Item { height: 4; width: 1 }

                Row {
                    spacing: 8
                    anchors.horizontalCenter: parent.horizontalCenter
                    property int btnWidth: Math.max(loginButton.implicitWidth,
                                                    shutdownButton.implicitWidth,
                                                    rebootButton.implicitWidth, 90) + 16

                    Button {
                        id: loginButton
                        text: textConstants.login
                        width: parent.btnWidth
                        color: "#2EA3F2"
                        textColor: '#ffffff'
                        activeColor: '#268acc'
                        onClicked: sddm.login(name.text, password.text, session.index)

                        KeyNavigation.backtab: layoutBox; KeyNavigation.tab: shutdownButton
                    }

                    Button {
                        id: shutdownButton
                        text: textConstants.shutdown
                        width: parent.btnWidth
                        color: "#3f4347"
                        textColor: '#eff0f1'
                        activeColor: '#2EA3F2'

                        onClicked: sddm.powerOff()

                        KeyNavigation.backtab: loginButton; KeyNavigation.tab: rebootButton
                    }

                    Button {
                        id: rebootButton
                        text: textConstants.reboot
                        width: parent.btnWidth
                        color: "#3f4347"
                        textColor: '#eff0f1'
                        activeColor: '#2EA3F2'

                        onClicked: sddm.reboot()

                        KeyNavigation.backtab: shutdownButton; KeyNavigation.tab: name
                    }
                }
            }
        }
    }

    Component.onCompleted: {
        if (name.text == "")
            name.focus = true
        else
            password.focus = true
    }
}
